#1. Read, 2. Processing, 3. Write

def ReadFile(Acc):  #Read
    try:
        count = 0
        INFILE = open("Data.txt",'r')           #r, reading
        for line in INFILE:                     #Read all the lines in INFILE
                Acc.append(line.rstrip())
                count = count + 1
        INFILE.close()                          #Closing the file we opened
        return count
    except:
        print("Error!, File could not be read")
        exit()
        
def Decode(inputList, outputList):  #Analyse(Processing)
    for entry in inputList:
        cardtype = entry [0:2]
        if int(cardtype) == 1:
            cardtype = "enRoute"
        elif int(cardtype) == 2:
            cardtype = "JCB"
        elif  int(cardtype) == 3:
            cardtype = "Diner's club"
        elif int(cardtype) == 4:
            cardtype = "Visa"
        elif int(cardtype) == 5:
            cardtype = "Master Card"
        elif int(cardtype) == 6:
            cardtype = "UnionPay"
        elif int(cardtype) == 7:
            cardtype = "Petroleum"
        elif int(cardtype) == 8:
            cardtype = "Telecom"
        elif int(cardtype) == 9:
            cardtype = "National"
            
        y = entry[2:3+1]        #year
        d = entry[4:5+1]        #day
        m = entry[6:7+1]        #month
        accnum = entry[8:]
        if int(accnum[0]) == 0:
            atype = "Debit account"
        elif int(accnum[0]) == 1:
            atype = "Credit account"  
        outputList.append(entry + ": Was issued by " + cardtype + " in 20" + y + ". The card expires on " + d + "/" + m +". The card is linked to a "+ atype + " with account number: " + accnum + ".")
        
def WriteFile(outputList):          #Write
    OUTFILE = open("Output.txt",'w')
    for cardnum in outputList:
            OUTFILE.write(cardnum + "\n")       #Write the card number to the output file
    OUTFILE.close()                             #close the file
    
inputList = []
outputList = []
print("Reading card numbers from file...")
print("Number of lines read: ",ReadFile(inputList))
Decode(inputList, outputList)
print()
print("Analysing card numbers...")
WriteFile(outputList)
print("See the output file for the extracted information")
