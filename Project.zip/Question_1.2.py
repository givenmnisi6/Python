
plaintext = input("Enter a message: ")
distance = int(input("Enter the distance value: "))
output = ""
for ch in plaintext:
    order = ord(ch)                       
    cipher = order + distance
    if cipher > ord('z'):
        cipher = ord('a')+ distance - \
                      (ord('z') - order + 1)
    output = output + chr(cipher)                 
print("The encoded message is: ",output)
