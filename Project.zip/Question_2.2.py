
import math
flag = True
while flag:
    print()
    item = str(input("Enter the name of an item: "))
    if (item=='x'):
        flag = False
        break
    price = int(input("Enter the item price: R "))
    print("Item name: ",item)
    if price > 250:
        percentage = 0.075

    elif price > 101 and price < 249:
        percentage = 0.1
    
    elif price < 100:
        percentage = 0.15

    VAT = price * percentage
    total = price + VAT

    print("VAT amount: R ", round(VAT,2))
    print("Total inc VAT: R ", round(total,2))
