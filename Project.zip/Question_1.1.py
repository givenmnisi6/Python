
n = int(input("Enter the number of terms for FizzBuzz: "))
for number in range(1, n+1):   
    if number % 15 == 0:
        print("FizzBuzz")
    elif number % 5 == 0:
        print("Buzz")
    elif number % 3 == 0:
        print("Fizz")
    else:
        print(number)
        
    
