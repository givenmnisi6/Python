
import math
#0 is equal to false
#1 is equal to true
#flag = 0, its initial value is false
#sum = 0, ensure that we have a summation of all the values
#if num<0, when the user enters a negative value the flag no 1 is a true and the execution will stop
#sum = sum + num, starts at zero, so itll add a value to the 'num'
#lowest.append, adding all the items in the lowest list
#highest.append, adds all the items in the highest list
#len, returning the number to string
#highest = [], empty list for highest values

flag = 0            
count = 0
sum = 0      
i = 1
maximum = []
lowest = []

print("Please enter values (negative value to stop)")
while not flag == 1:
   num = float(input("Enter value number " + str(i)+ ": "))
   i = i + 1
   if num<0:             
        flag = 1   
   else:
        sum = sum + num  
        if num<1:
            lowest.append(num) 
        elif num>=1:
            maximum.append(num)
        else:
            maximum.append(num)
print()
print("Number of values entered: ",(i-1))
if (len(maximum)>0):        
    print("The highest value is: ",max(maximum))
else:
    print("The highest value is: ",max(lowest))

if (len(lowest)>0):
    print("The lowest value is: ",min(lowest))
else:
    print("The lowest value is: ",min(maximum))   
print("The average value is: ",round(sum/(i),3))
